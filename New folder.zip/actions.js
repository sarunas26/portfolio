class Actions {
    constructor(inventory) {
        this.inventory = inventory;
    }

    performAction(tile, actionName) {
        if (this[actionName] && typeof this[actionName] === 'function') {
            this[actionName](tile);
            startActionProgress();
        }
    }

    cutTree(tile) {
        if (tile.type === 'tree') {
            tile.type = 'grass';
            tile.element.className = `tile ${tile.type}`;
            this.inventory.addItem('Wood', 1);
        }
    }

    fish(tile) {
        if (tile.type === 'water') {
            this.inventory.addItem('Fish', 1);
        }
    }
}
