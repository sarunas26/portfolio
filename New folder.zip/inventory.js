class Inventory {
    constructor() {
        this.items = {};
    }

    addItem(item, count) {
        if (this.items[item]) {
            this.items[item] += count;
        } else {
            this.items[item] = count;
        }
        this.updateInventoryDisplay();
    }

    getItemCount(item) {
        return this.items[item] || 0;
    }

    removeItem(item, count) {
        if (this.items[item]) {
            this.items[item] -= count;
            if (this.items[item] < 0) {
                this.items[item] = 0;
            }
        }
        this.updateInventoryDisplay();
    }

    updateInventoryDisplay() {
        const inventoryElement = document.getElementById('inventory');
        inventoryElement.innerHTML = '';

        for (const [item, count] of Object.entries(this.items)) {
            const listItem = document.createElement('li');
            listItem.classList.add('list-group-item');
            listItem.textContent = `${item}: ${count}`;
            inventoryElement.appendChild(listItem);
        }
    }
}
