function startActionProgress() {
    let progress = 0;

    function updateProgress() {
        const progressBar = document.getElementById('action-progress');
        if (progressBar) {
            if (progress < 100) {
                progress += 10;
                progressBar.style.width = progress + '%';
                setTimeout(updateProgress, 100);
            } else {
                progressBar.style.width = '0%';
            }
        }
    }

    updateProgress();
}

const inventory = new Inventory();
const tilemap = new Tilemap(tilemapData.tiles, inventory);
const container = document.getElementById('tilemap');
tilemap.render(container);