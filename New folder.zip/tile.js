class Tile {
    constructor(typeNumber, inventory, x, y) {
        this.type = this.mapTypeNumberToType(typeNumber);
        this.x = x;
        this.y = y;
        this.actions = new Actions(inventory);
    }

    mapTypeNumberToType(typeNumber) {
        const typeMapping = {
            1: 'deep_water',
            2: 'water',
            3: 'sand',
            4: 'grass',
            5: 'tree',
            6: 'house',
            7: 'rock'
        };

        return typeMapping[typeNumber] || 'water';
    }

    createTileElement() {
        const tileElement = document.createElement('div');
        tileElement.className = 'tile ' + this.type;
        tileElement.addEventListener('click', () => {
            this.handleClick(this);
        });
        this.element = tileElement;

        return tileElement;
    }

    handleClick(tile) {
        this.updateTileInfo(tile);
        this.updateActionButtons(tile);
    }

    updateTileInfo(tile) {
        const tileInfo = document.getElementById('tile-info');
        tileInfo.innerHTML = `Type: ${tile.type}<br>Coordinates: (${tile.x}, ${tile.y})`;
    }

    updateActionButtons(tile) {
        const cutTreeAction = document.getElementById('cut-tree-action');
        const fishAction = document.getElementById('fish-action');

        cutTreeAction.style.display = tile.type === 'tree' ? 'block' : 'none';
        fishAction.style.display = tile.type === 'water' ? 'block' : 'none';

        const cutTreeButton = document.getElementById('cut-tree');
        const fishButton = document.getElementById('fish');

        cutTreeButton.onclick = () => {
            this.actions.performAction(tile, 'cutTree');
        };

        fishButton.onclick = () => {
            this.actions.performAction(tile, 'fish');
        };
    }
}