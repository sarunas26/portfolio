const tilemapData = {
    "tiles": [
        [1, 1, 1, 2, 2, 2, 1, 1, 1, 1],
        [1, 1, 2, 3, 3, 3, 2, 1, 1, 1],
        [1, 2, 3, 4, 4, 4, 3, 2, 1, 1],
        [2, 3, 4, 5, 5, 5, 4, 3, 2, 1],
        [2, 3, 4, 5, 6, 7, 4, 3, 2, 1],
        [2, 3, 4, 5, 5, 5, 4, 3, 2, 1],
        [1, 2, 3, 4, 4, 4, 3, 2, 2, 1],
        [1, 1, 2, 3, 3, 3, 2, 2, 1, 1],
        [1, 1, 1, 2, 2, 2, 1, 1, 1, 1]
    ]
};

class Tilemap {
    constructor(tilesData, inventory) {
        this.tilesData = tilesData;
        this.tiles = [];
        this.inventory = inventory;
        this.parseTiles();
    }

    parseTiles() {
        this.tilesData.forEach((rowData, rowIndex) => {
            const row = rowData.map((tileType, colIndex) => new Tile(tileType, this.inventory, rowIndex, colIndex));
            this.tiles.push(row);
        });
    }


    render(container) {
        this.tiles.forEach(row => {
            const rowDiv = document.createElement('div');
            rowDiv.classList.add('row');
            row.forEach(tile => {
                rowDiv.appendChild(tile.createTileElement());
            });
            container.appendChild(rowDiv);
        });
    }
}